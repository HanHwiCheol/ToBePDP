// pages/scenario/[id].tsx
"use client";

import { useRouter } from "next/router";
import { useEffect, useState } from "react";
import * as XLSX from "xlsx";

export default function ScenarioLoaderPage() {
  const router = useRouter();
  const { id } = router.query;

  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");

  useEffect(() => {
    if (!id) return;

    const loadScenario = async () => {
      try {
        setLoading(true);

        // 1) 시나리오 파일 경로 만들기
        const filePath = `/scenario/${id}.xlsx`;

        console.log("📄 Loading scenario file:", filePath);

        // 2) 파일 불러오기
        const res = await fetch(filePath);
        if (!res.ok) throw new Error(`파일을 불러올 수 없습니다: ${filePath}`);

        const arrayBuffer = await res.arrayBuffer();

        // 3) XLSX 파싱
        const workbook = XLSX.read(arrayBuffer, { type: "array" });
        const sheet = workbook.Sheets[workbook.SheetNames[0]];

        const json = XLSX.utils.sheet_to_json(sheet);
        console.log("📊 Parsed BOM Data:", json);

        // 4) 파싱된 row를 TreeGrid 형식에 맞게 변환 (필요 시 커스텀 가능)
        const rows = json.map((row: any, index: number) => ({
          id: index + 1,
          line_no: row["line_no"] ?? "",
          part_no: row["part_no"] ?? "",
          revision: row["revision"] ?? "",
          name: row["name"] ?? "",
          created_at: "",
          updated_at: "",
          material: row["material"] ?? "",
          qty: row["qty"] ?? 1,
          qty_uom: "ea",
          total_mass_kg: row["mass_kg"] ?? 0,
        }));

        console.log("➡️ TreeGrid Rows:", rows);

        // 5) 로컬 스토리지에 저장 후 tree 화면으로 이동
        localStorage.setItem("scenarioRows", JSON.stringify(rows));

        // 6) BOM 화면으로 이동 (네 프로젝트의 BOM 테이블 페이지)
        router.push("/treetable");

      } catch (err: any) {
        console.error("Error loading scenario:", err);
        setError(err.message);
      } finally {
        setLoading(false);
      }
    };

    loadScenario();
  }, [id]);

  if (loading) {
    return (
      <div style={{ padding: 40, textAlign: "center" }}>
        <h3>시나리오 데이터를 불러오는 중입니다...</h3>
      </div>
    );
  }

  if (error) {
    return (
      <div style={{ padding: 40, textAlign: "center", color: "red" }}>
        <h3>오류 발생: {error}</h3>
      </div>
    );
  }

  return null;
}
