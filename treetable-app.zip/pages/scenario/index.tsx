// pages/scenario/index.tsx
import { useRouter } from "next/router";

export default function ScenarioSelectPage() {
  const router = useRouter();

  const handleSelect = (scenario: string) => {
    router.push(`/scenario/${scenario}`);
  };

  return (
    <div style={{ maxWidth: 600, margin: "80px auto", padding: 32 }}>
      <h1 style={{ fontSize: 24, fontWeight: "bold", marginBottom: 24 }}>
        시나리오를 선택하세요
      </h1>

      <button style={btn} onClick={() => handleSelect("material-change")}>
        재질 변경 시나리오
      </button>

      <button style={btn} onClick={() => handleSelect("size-change")}>
        크기 변경 시나리오
      </button>

      <button style={btn} onClick={() => handleSelect("structure-change")}>
        BOM 구조 변경 시나리오
      </button>
    </div>
  );
}

const btn = {
  width: "100%",
  padding: "14px 20px",
  background: "#2563eb",
  color: "white",
  borderRadius: 8,
  marginBottom: 16,
};
